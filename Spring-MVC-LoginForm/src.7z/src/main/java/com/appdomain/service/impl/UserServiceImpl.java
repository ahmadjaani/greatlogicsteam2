package com.appdomain.service.impl;

import java.util.List;

import com.appdomain.pojo.Employee;
import com.appdomain.service.UserService;

public class UserServiceImpl implements UserService {

	@Override
	public List<Employee> getAllEmployees() {
		return null;
	}

}

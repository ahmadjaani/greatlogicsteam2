package com.appdomain.service;

import java.util.List;

import com.appdomain.pojo.Employee;

public interface UserService {

	List<Employee> getAllEmployees();
}

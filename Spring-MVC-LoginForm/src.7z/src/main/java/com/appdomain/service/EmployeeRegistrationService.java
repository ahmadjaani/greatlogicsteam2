package com.appdomain.service;

import com.appdomain.dto.UserDTO;

public interface EmployeeRegistrationService {
	
	public void insertEmployeeInToDB(UserDTO userData);

}

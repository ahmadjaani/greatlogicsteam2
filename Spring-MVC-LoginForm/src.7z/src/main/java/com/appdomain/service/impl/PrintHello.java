package com.appdomain.service.impl;

import com.appdomain.service.PrintHelloInterface;

public class PrintHello implements PrintHelloInterface {
	
	public void justSayHello(){
		System.out.println("Hi Hello this is a bean config");
	}

}

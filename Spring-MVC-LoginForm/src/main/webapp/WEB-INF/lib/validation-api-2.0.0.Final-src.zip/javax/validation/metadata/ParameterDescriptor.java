package javax.validation.metadata;

import javax.validation.metadata.CascadableDescriptor;
import javax.validation.metadata.ContainerDescriptor;
import javax.validation.metadata.ElementDescriptor;

public interface ParameterDescriptor extends ElementDescriptor, CascadableDescriptor, ContainerDescriptor {
	int getIndex();

	String getName();
}
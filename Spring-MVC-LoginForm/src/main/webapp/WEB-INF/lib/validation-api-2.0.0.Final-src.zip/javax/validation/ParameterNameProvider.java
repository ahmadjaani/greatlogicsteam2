package javax.validation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

public interface ParameterNameProvider {
	List<String> getParameterNames(Constructor<?> arg0);

	List<String> getParameterNames(Method arg0);
}
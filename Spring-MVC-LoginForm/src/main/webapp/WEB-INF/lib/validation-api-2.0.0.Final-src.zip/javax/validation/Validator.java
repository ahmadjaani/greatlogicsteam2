package javax.validation;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.executable.ExecutableValidator;
import javax.validation.metadata.BeanDescriptor;

public interface Validator {
	<T> Set<ConstraintViolation<T>> validate(T arg0, Class... arg1);

	<T> Set<ConstraintViolation<T>> validateProperty(T arg0, String arg1, Class... arg2);

	<T> Set<ConstraintViolation<T>> validateValue(Class<T> arg0, String arg1, Object arg2, Class... arg3);

	BeanDescriptor getConstraintsForClass(Class<?> arg0);

	<T> T unwrap(Class<T> arg0);

	ExecutableValidator forExecutables();
}
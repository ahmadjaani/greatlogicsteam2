package javax.validation.metadata;

import javax.validation.metadata.ElementDescriptor;

public interface CrossParameterDescriptor extends ElementDescriptor {
	Class<?> getElementClass();
}
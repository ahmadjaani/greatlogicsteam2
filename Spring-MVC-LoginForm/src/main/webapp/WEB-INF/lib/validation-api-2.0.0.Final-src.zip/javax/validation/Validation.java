package javax.validation;

import javax.validation.Configuration;
import javax.validation.ValidatorFactory;import javax.validation.Validation.1;
import javax.validation.Validation.GenericBootstrapImpl;
import javax.validation.Validation.GetValidationProviderListAction;
import javax.validation.Validation.ProviderSpecificBootstrapImpl;
import javax.validation.bootstrap.GenericBootstrap;
import javax.validation.bootstrap.ProviderSpecificBootstrap;
import javax.validation.spi.ValidationProvider;

public class Validation {
	public static ValidatorFactory buildDefaultValidatorFactory() {
		return byDefaultProvider().configure().buildValidatorFactory();
	}

	public static GenericBootstrap byDefaultProvider() {
      return new GenericBootstrapImpl((1)null);
   }

	public static <T extends Configuration<T>, U extends ValidationProvider<T>> ProviderSpecificBootstrap<T> byProvider(
			Class<U> providerType) {
		return new ProviderSpecificBootstrapImpl(providerType);
	}

	private static void clearDefaultValidationProviderResolverCache() {
		GetValidationProviderListAction.clearCache();
	}
}
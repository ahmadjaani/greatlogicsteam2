package javax.validation;

public interface Payload {
}
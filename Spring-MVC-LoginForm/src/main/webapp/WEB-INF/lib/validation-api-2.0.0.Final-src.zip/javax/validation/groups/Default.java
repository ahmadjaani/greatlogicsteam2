package javax.validation.groups;

public interface Default {
}
package javax.validation;

import javax.validation.ClockProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.MessageInterpolator;
import javax.validation.ParameterNameProvider;
import javax.validation.TraversableResolver;
import javax.validation.Validator;
import javax.validation.ValidatorContext;

public interface ValidatorFactory extends AutoCloseable {
	Validator getValidator();

	ValidatorContext usingContext();

	MessageInterpolator getMessageInterpolator();

	TraversableResolver getTraversableResolver();

	ConstraintValidatorFactory getConstraintValidatorFactory();

	ParameterNameProvider getParameterNameProvider();

	ClockProvider getClockProvider();

	<T> T unwrap(Class<T> arg0);

	void close();
}
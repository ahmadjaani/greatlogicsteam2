package javax.validation.metadata;

public interface GroupConversionDescriptor {
	Class<?> getFrom();

	Class<?> getTo();
}
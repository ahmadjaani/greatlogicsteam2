package javax.validation.metadata;

public enum MethodType {
	GETTER, NON_GETTER;
}
package javax.validation;

import java.util.Locale;
import javax.validation.MessageInterpolator.Context;

public interface MessageInterpolator {
	String interpolate(String arg0, Context arg1);

	String interpolate(String arg0, Context arg1, Locale arg2);
}
package javax.validation;

public enum ConstraintTarget {
	IMPLICIT, RETURN_VALUE, PARAMETERS;
}
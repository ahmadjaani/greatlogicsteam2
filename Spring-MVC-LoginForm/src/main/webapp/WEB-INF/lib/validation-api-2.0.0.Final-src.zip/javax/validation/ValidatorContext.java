package javax.validation;

import javax.validation.ClockProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.MessageInterpolator;
import javax.validation.ParameterNameProvider;
import javax.validation.TraversableResolver;
import javax.validation.Validator;
import javax.validation.valueextraction.ValueExtractor;

public interface ValidatorContext {
	ValidatorContext messageInterpolator(MessageInterpolator arg0);

	ValidatorContext traversableResolver(TraversableResolver arg0);

	ValidatorContext constraintValidatorFactory(ConstraintValidatorFactory arg0);

	ValidatorContext parameterNameProvider(ParameterNameProvider arg0);

	ValidatorContext clockProvider(ClockProvider arg0);

	ValidatorContext addValueExtractor(ValueExtractor<?> arg0);

	Validator getValidator();
}
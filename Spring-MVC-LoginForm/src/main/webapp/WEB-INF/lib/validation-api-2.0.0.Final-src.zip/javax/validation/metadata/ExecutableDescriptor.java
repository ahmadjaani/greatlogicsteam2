package javax.validation.metadata;

import java.util.List;
import java.util.Set;
import javax.validation.metadata.ConstraintDescriptor;
import javax.validation.metadata.CrossParameterDescriptor;
import javax.validation.metadata.ElementDescriptor;
import javax.validation.metadata.ParameterDescriptor;
import javax.validation.metadata.ReturnValueDescriptor;
import javax.validation.metadata.ElementDescriptor.ConstraintFinder;

public interface ExecutableDescriptor extends ElementDescriptor {
	String getName();

	List<ParameterDescriptor> getParameterDescriptors();

	CrossParameterDescriptor getCrossParameterDescriptor();

	ReturnValueDescriptor getReturnValueDescriptor();

	boolean hasConstrainedParameters();

	boolean hasConstrainedReturnValue();

	boolean hasConstraints();

	Set<ConstraintDescriptor<?>> getConstraintDescriptors();

	ConstraintFinder findConstraints();
}
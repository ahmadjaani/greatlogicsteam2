package javax.validation.metadata;

import java.util.Set;
import javax.validation.metadata.ConstraintDescriptor;
import javax.validation.metadata.ElementDescriptor.ConstraintFinder;

public interface ElementDescriptor {
	boolean hasConstraints();

	Class<?> getElementClass();

	Set<ConstraintDescriptor<?>> getConstraintDescriptors();

	ConstraintFinder findConstraints();
}
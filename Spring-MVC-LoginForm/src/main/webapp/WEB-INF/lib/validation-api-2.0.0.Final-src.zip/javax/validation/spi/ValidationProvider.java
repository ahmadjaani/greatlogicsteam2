package javax.validation.spi;

import javax.validation.Configuration;
import javax.validation.ValidatorFactory;
import javax.validation.spi.BootstrapState;
import javax.validation.spi.ConfigurationState;

public interface ValidationProvider<T extends Configuration<T>> {
	T createSpecializedConfiguration(BootstrapState arg0);

	Configuration<?> createGenericConfiguration(BootstrapState arg0);

	ValidatorFactory buildValidatorFactory(ConfigurationState arg0);
}
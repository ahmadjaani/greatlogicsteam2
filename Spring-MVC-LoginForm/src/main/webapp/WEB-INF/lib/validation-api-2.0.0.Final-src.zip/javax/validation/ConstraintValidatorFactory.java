package javax.validation;

import javax.validation.ConstraintValidator;

public interface ConstraintValidatorFactory {
	<T extends ConstraintValidator<?, ?>> T getInstance(Class<T> arg0);

	void releaseInstance(ConstraintValidator<?, ?> arg0);
}
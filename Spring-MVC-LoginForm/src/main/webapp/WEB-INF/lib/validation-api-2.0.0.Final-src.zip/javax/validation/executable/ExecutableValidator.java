package javax.validation.executable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Set;
import javax.validation.ConstraintViolation;

public interface ExecutableValidator {
	<T> Set<ConstraintViolation<T>> validateParameters(T arg0, Method arg1, Object[] arg2, Class... arg3);

	<T> Set<ConstraintViolation<T>> validateReturnValue(T arg0, Method arg1, Object arg2, Class... arg3);

	<T> Set<ConstraintViolation<T>> validateConstructorParameters(Constructor<? extends T> arg0, Object[] arg1,
			Class... arg2);

	<T> Set<ConstraintViolation<T>> validateConstructorReturnValue(Constructor<? extends T> arg0, T arg1,
			Class... arg2);
}
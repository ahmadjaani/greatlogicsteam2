package javax.validation;

import java.lang.annotation.Annotation;
import javax.validation.ConstraintValidatorContext;

public interface ConstraintValidator<A extends Annotation, T> {
	default void initialize(A constraintAnnotation) {
	}

	boolean isValid(T arg0, ConstraintValidatorContext arg1);
}
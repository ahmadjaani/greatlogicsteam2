package javax.validation;

import javax.validation.ClockProvider;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

public interface ConstraintValidatorContext {
	void disableDefaultConstraintViolation();

	String getDefaultConstraintMessageTemplate();

	ClockProvider getClockProvider();

	ConstraintViolationBuilder buildConstraintViolationWithTemplate(String arg0);

	<T> T unwrap(Class<T> arg0);
}
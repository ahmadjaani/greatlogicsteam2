package javax.validation.metadata;

public enum Scope {
	LOCAL_ELEMENT, HIERARCHY;
}
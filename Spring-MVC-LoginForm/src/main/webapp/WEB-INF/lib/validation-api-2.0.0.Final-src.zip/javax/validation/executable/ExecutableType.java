package javax.validation.executable;

public enum ExecutableType {
	IMPLICIT, NONE, CONSTRUCTORS, NON_GETTER_METHODS, GETTER_METHODS, ALL;
}
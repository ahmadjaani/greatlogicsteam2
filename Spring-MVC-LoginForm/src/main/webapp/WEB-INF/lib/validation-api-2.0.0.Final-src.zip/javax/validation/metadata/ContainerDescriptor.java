package javax.validation.metadata;

import java.util.Set;
import javax.validation.metadata.ContainerElementTypeDescriptor;

public interface ContainerDescriptor {
	Set<ContainerElementTypeDescriptor> getConstrainedContainerElementTypes();
}
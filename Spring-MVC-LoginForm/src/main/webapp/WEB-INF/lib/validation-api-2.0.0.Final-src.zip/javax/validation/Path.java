package javax.validation;

import javax.validation.Path.Node;

public interface Path extends Iterable<Node> {
	String toString();
}
package javax.validation.constraintvalidation;

public enum ValidationTarget {
	ANNOTATED_ELEMENT, PARAMETERS;
}
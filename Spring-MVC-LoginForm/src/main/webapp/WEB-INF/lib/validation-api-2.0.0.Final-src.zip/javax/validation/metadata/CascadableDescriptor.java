package javax.validation.metadata;

import java.util.Set;
import javax.validation.metadata.GroupConversionDescriptor;

public interface CascadableDescriptor {
	boolean isCascaded();

	Set<GroupConversionDescriptor> getGroupConversions();
}
package javax.validation.metadata;

import javax.validation.metadata.ExecutableDescriptor;

public interface ConstructorDescriptor extends ExecutableDescriptor {
}
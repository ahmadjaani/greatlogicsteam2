package javax.validation.metadata;

public enum ValidateUnwrappedValue {
	DEFAULT, UNWRAP, SKIP;
}
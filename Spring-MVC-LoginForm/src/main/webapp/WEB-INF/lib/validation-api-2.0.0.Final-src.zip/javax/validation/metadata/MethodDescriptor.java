package javax.validation.metadata;

import javax.validation.metadata.ExecutableDescriptor;

public interface MethodDescriptor extends ExecutableDescriptor {
}
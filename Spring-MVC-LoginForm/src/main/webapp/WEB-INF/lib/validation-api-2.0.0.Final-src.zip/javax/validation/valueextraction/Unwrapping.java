package javax.validation.valueextraction;

public interface Unwrapping {
}
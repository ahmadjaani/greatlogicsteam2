package javax.validation.metadata;

import java.util.Set;
import javax.validation.metadata.ConstructorDescriptor;
import javax.validation.metadata.ElementDescriptor;
import javax.validation.metadata.MethodDescriptor;
import javax.validation.metadata.MethodType;
import javax.validation.metadata.PropertyDescriptor;

public interface BeanDescriptor extends ElementDescriptor {
	boolean isBeanConstrained();

	PropertyDescriptor getConstraintsForProperty(String arg0);

	Set<PropertyDescriptor> getConstrainedProperties();

	MethodDescriptor getConstraintsForMethod(String arg0, Class... arg1);

	Set<MethodDescriptor> getConstrainedMethods(MethodType arg0, MethodType... arg1);

	ConstructorDescriptor getConstraintsForConstructor(Class... arg0);

	Set<ConstructorDescriptor> getConstrainedConstructors();
}
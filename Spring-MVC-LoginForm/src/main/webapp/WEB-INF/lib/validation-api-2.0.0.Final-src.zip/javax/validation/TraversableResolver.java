package javax.validation;

import java.lang.annotation.ElementType;
import javax.validation.Path;
import javax.validation.Path.Node;

public interface TraversableResolver {
	boolean isReachable(Object arg0, Node arg1, Class<?> arg2, Path arg3, ElementType arg4);

	boolean isCascadable(Object arg0, Node arg1, Class<?> arg2, Path arg3, ElementType arg4);
}
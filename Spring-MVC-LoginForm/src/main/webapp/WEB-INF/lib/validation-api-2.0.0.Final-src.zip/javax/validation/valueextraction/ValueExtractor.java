package javax.validation.valueextraction;

import javax.validation.valueextraction.ValueExtractor.ValueReceiver;

public interface ValueExtractor<T> {
	void extractValues(T arg0, ValueReceiver arg1);
}
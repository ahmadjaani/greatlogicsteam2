package javax.validation;

import java.io.InputStream;
import javax.validation.BootstrapConfiguration;
import javax.validation.ClockProvider;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.MessageInterpolator;
import javax.validation.ParameterNameProvider;
import javax.validation.TraversableResolver;
import javax.validation.ValidatorFactory;
import javax.validation.valueextraction.ValueExtractor;

public interface Configuration<T extends Configuration<T>> {
	T ignoreXmlConfiguration();

	T messageInterpolator(MessageInterpolator arg0);

	T traversableResolver(TraversableResolver arg0);

	T constraintValidatorFactory(ConstraintValidatorFactory arg0);

	T parameterNameProvider(ParameterNameProvider arg0);

	T clockProvider(ClockProvider arg0);

	T addValueExtractor(ValueExtractor<?> arg0);

	T addMapping(InputStream arg0);

	T addProperty(String arg0, String arg1);

	MessageInterpolator getDefaultMessageInterpolator();

	TraversableResolver getDefaultTraversableResolver();

	ConstraintValidatorFactory getDefaultConstraintValidatorFactory();

	ParameterNameProvider getDefaultParameterNameProvider();

	ClockProvider getDefaultClockProvider();

	BootstrapConfiguration getBootstrapConfiguration();

	ValidatorFactory buildValidatorFactory();
}
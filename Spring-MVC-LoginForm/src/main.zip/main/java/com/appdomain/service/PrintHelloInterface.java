package com.appdomain.service;

public interface PrintHelloInterface {

	public void justSayHello();
	
}

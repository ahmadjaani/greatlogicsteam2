package com.appdomain.service;

import java.util.List;

import com.appdomain.dto.SpringEmployeeDTO;

public interface GetAllEmployeesServiceInterface {

	
	public List<SpringEmployeeDTO> getAllEmployeesFromDB();
	
}

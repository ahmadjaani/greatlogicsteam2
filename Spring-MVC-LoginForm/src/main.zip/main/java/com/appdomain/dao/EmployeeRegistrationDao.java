package com.appdomain.dao;

import com.appdomain.dto.UserDTO;

public interface EmployeeRegistrationDao {
	
	public void insertEmployeeInToDB(UserDTO userData);

}

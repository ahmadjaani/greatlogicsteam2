package com.appdomain.dao.mapper;


import com.appdomain.pojo.Employee;

public class UserMapper{
	
}